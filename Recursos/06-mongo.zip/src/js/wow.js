// ::::::::::: wow :::::::::::: //
"use strict";

(() => {
  new WOW().init();
})();
